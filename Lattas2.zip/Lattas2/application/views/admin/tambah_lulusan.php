<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Tambah
              <small>Lulusan</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/lulusan">Lulusan</a></li>
              <li class="active">Tambah</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Tambah Data Lulusan</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/insert_lulusan'); ?>
					
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama, Alamat dan No Telp</label>
                      <textarea name="identitas_lembaga" class="form-control" cols="30" rows="10" ></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Pimpinan</label>
                      <input type="text" class="form-control" name="nama_pimpinan" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">No Ijin</label>
                      <input type="text" class="form-control" name="no_ijin" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control" multiple="multiple">
                        <?php  
                        $kode_kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        foreach ($kode_kejuruan as $kejuruan) {
                          echo "<option  value='$kejuruan->nama_kejuruan'>".ucwords($kejuruan->nama_kejuruan)."</option>"; 
                        }
                        ?>
                      </select>
					  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Kapasitas Latih</label>
                      <input type="text" class="form-control" name="kapasitas" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Dilatih (L)</label>
                      <input type="text" class="form-control" name="dilatih_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Dilatih (P)</label>
                      <input type="text" class="form-control" name="dilatih_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Lulusan (L)</label>
                      <input type="text" class="form-control" name="lulusan_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Lulusan (P)</label>
                      <input type="text" class="form-control" name="lulusan_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja di perusahaan (L)</label>
                      <input type="text" class="form-control" name="perusahaan_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja di perusahaan (P)</label>
                      <input type="text" class="form-control" name="perusahaan_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja Mandiri (L)</label>
                      <input type="text" class="form-control" name="mandiri_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja Mandiri (P)</label>
                      <input type="text" class="form-control" name="mandiri_p" />
                  </div>
                 
				  
                  <a href="<?php echo base_url(); ?>index.php/admins/lulusan" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php echo form_close(); ?>
                
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>