<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	   <meta charset="utf-8">
					  <meta name="viewport" content="width=device-width, initial-scale=1">
					  <title>jQuery UI Datepicker - Default functionality</title>
					  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
					  <link rel="stylesheet" href="/resources/demos/style.css">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Edit
              <small>Lembaga</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/lembaga">Lembaga</a></li>
              <li class="active">Edit</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Lembaga</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/update_lembaga'); ?>
                <?php  
                foreach ($editdata as $data):
                ?>
              
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Lembaga</label>
                      <input type="text" class="form-control" name="nama" value="<?php echo $data->nama ?>"/>
                  </div>
				   <div class="form-group">
                    <label for="exampleInputEmail1">Alamat Lembaga</label>
                      <input type="text" class="form-control" name="alamat" value="<?php echo $data->alamat ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telpon</label>
                      <input type="text" class="form-control" name="telp" value="<?php echo $data->telp ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Penanggung Jawab</label>
                      <input type="text" class="form-control" name="penanggung_jawab" value="<?php echo $data->penanggung_jawab ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tanggal Izin</label>
					<input type="text" class="form-control" id="datepicker" data-date-format="yyyy-mm-dd" name="tgl_izin" value="<?php echo $data->tgl_izin ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control" multiple="multiple">
                        <?php
                        $kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        
                        if (empty($kejuruan)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kejuruan as $kejuruan){
                        ?>
                       <option <?php if( $data->kejuruan == $kejuruan->kode_kejuruan) {echo "selected"; } ?> value='<?php echo $kejuruan->nama_kejuruan ;?>'><?php echo $kejuruan->nama_kejuruan ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				  
                  <input type="hidden" name="id" value="<?php echo $data->kode_lembaga ?>">
                  <a href="<?php echo base_url(); ?>index.php/admins/lembaga" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php endforeach ?>
                <?php echo form_close(); ?>
              </div><!-- /.box-body -->
			  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
					  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
					  <script>
					  $( function() {
						$( "#datepicker" ).datepicker();
					  } );
					  </script>
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>