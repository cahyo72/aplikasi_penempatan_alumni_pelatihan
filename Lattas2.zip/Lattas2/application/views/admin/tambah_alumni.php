<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	  <meta charset="utf-8">
					  <meta name="viewport" content="width=device-width, initial-scale=1">
					  <title>jQuery UI Datepicker - Default functionality</title>
					  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
					  <link rel="stylesheet" href="/resources/demos/style.css">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Tambah
              <small>Alumni</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/alumni">Alumni</a></li>
              <li class="active">Tambah</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Tambah Data Alumni</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/insert_alumni'); ?>
   
				  <div class="form-group">
				   <div class="row">
				   <div class="col-lg-2" >
						<label>Tahun Angkatan</label>
						<select name="ta"  class="form-control">
						<option>2014</option>
						<option>2015</option>
						<option>2016</option>
						<option>2017</option>
						</select>
				 </div>
				  
				   <div class="col-lg-10" >                  
                    <label for="exampleInputEmail1">Nama Alumni</label>
                      <input type="text" class="form-control" name="nama"/>
                  </div>
					</div>
						</div>
						
                  <div class="form-group">
				  <div class="row">
				   <div class="col-lg-5" >
                    <label for="exampleInputEmail1">Tempat Lahir</label>
                     <select name="tempatlahir" class="form-control" >
                        <?php  
                        $id_kabupaten = $this->db->query("SELECT * FROM kabupaten")->result();
                        foreach ($id_kabupaten as $kabupaten) {
                          echo "<option  value='$kabupaten->nama_kabupaten'>".ucwords($kabupaten->nama_kabupaten)."</option>"; 
                        }
                        ?>
                      </select>
                  </div>
				  <div class="col-lg-4" >
                    <label for="date">Tanggal Lahir</label>
					 <input type="date" class="form-control" id="datepicker" data-date-format="yyyy-mm-dd" name="tgllahir"/>
                  </div>
				   <div class="col-lg-3" >
				   <label>Pendidikan</label>
						<select name="pendidikan"  class="form-control">
						<option>SMA</option>
						<option>SMK</option>
						<option>D3</option>
						<option>S1</option>
						</select>
						</div>
							</div>
								</div>

				  <div class="form-group">
				   <div class="row">
				   <div class="col-lg-7" >
                    <label for="exampleInputEmail1">Alamat</label>
                      <input type="text" class="form-control" name="alamat" />
					</div>
					<div class="col-lg-2">
                      <label for="exampleInputEmail1">Kabupaten</label>
						 <select name="kabupaten" class="form-control" >
                        <?php  
                        $id_kabupaten = $this->db->query("SELECT * FROM kabupaten")->result();
                        foreach ($id_kabupaten as $kabupaten) {
                          echo "<option  value='$kabupaten->nama_kabupaten'>".ucwords($kabupaten->nama_kabupaten)."</option>"; 
                        }
                        ?>
                      </select>
                  </div>
				  <div class="col-lg-3 ">
                      <label >Provinsi</label>
						 <select name="provinsi" class="form-control" >
                        <?php  
                        $id_provinsi = $this->db->query("SELECT * FROM provinsi")->result();
                        foreach ($id_provinsi as $provinsi) {
                          echo "<option  value='$provinsi->nama_provinsi'>".ucwords($provinsi->nama_provinsi)."</option>"; 
                        }
                        ?>
                      </select>
                  </div>
					</div>
						</div>
						
				  
				   <div class="form-group">
				   <div class="row">
				   <div class="col-lg-3" >
                    <label for="exampleInputEmail1">No HP</label>
                      <input type="text" class="form-control" name="nohp" />
                  </div>
				  <div class="col-lg-6">
				  <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control">
                        <?php  
                        $kode_kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        foreach ($kode_kejuruan as $kejuruan) {
                          echo "<option  value='$kejuruan->nama_kejuruan'>".ucwords($kejuruan->nama_kejuruan)."</option>"; 
                        }
                        ?>
                      </select>
				  </div>
				   <div class="col-lg-3" >
                    <label for="exampleInputEmail1">Keterangan</label>
                      <select name="keterangan"  class="form-control">
						<option>Lulus</option>
						<option>Tidak Lulus</option>
						</select>
                  </div>
					</div>
						</div>
						
						
				  
                  <a href="<?php echo base_url(); ?>index.php/admins/alumni_lulus" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php echo form_close(); ?>
                
              </div><!-- /.box-body -->
			  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
					  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
					  <script>
					  $( function() {
						$( "#datepicker" ).datepicker();
					  } );
					  </script>
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>