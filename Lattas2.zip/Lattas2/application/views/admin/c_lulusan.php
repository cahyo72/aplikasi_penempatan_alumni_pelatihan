<html>
	<head>
		<title>
		</title>

		<style>
			body {
				background-color: #D2D6DE;	
			}

			.endas {
				width: 300px;
				margin: 0px auto;
			}

			.layer-pertama {
				border: 0px solid #000;
				height: 900px;
				width: 1000px;
				margin: 100px auto;
				background-color: #fff;
			}

			.layer-kedua {
				margin: 0px auto;
				border: 0px solid #000;
				padding: 10px;
				background-color: #fff;
			}

			.head-surat {
				border: 0px solid #000;
				margin: 0px auto;
			}

			.head-surat h2 {
				text-align: center;
			}

			.isi-surat {
				border: 0px solid #000;
				margin: 25px auto;
			}

			.isi-surat table {
				margin: 10px auto 10px auto;
				border: 1px solid #000;
				border-collapse: collapse;
				width: 879px;
			}

			.logo {
				position: relative;
				border: 0px solid #000;
			}

			.logo table {
				border: 0px solid #000;
				border-collapse: collapse;
				width: 800px;
				text-align:center;
			}

			.tulisan-pemerintah {
				font-family: Arial;
				font-size: 26px;
			}

			.tulisan-dinas {
				font-family: Arial;
				font-size: 26px;

			}

			.tulisan-alamat {
				font-family: Arial;
				font-size: 18px;

			}

			.garis {
				height: 3px;
				background-color: #000;
				border: none;
				margin-bottom: 3px;
				margin-top: 10px;
			}

			.garis-tipis {
				height: 1px;
				background-color: #000;
				border: none;
			}

			.tulisan-judul {
				font-size: 12px;
				text-align: left;
				font-family: Arial;
				font-weight: bold;
			}

			.tulisan-judul_miring {
				font-size: 12px;
				text-align: left;
				font-family: Arial	;
				font-style: italic;
			}

			.tulisan-angka {
				font-size: 12px;
				padding: 7px;
				text-align: center;
				font-family: Times New Roman;
				font-weight: bold;
			}

			.raw {
   				 display: table;
   				 table-layout: fixed; /*Optional*/
   				 border-spacing: 10px; /*Optional*/
   				 font-size: 18px;
			}

			.column {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: left;
				 font-family: Times New Roman;
				 font-weight: bold;
			}

			.column_biasa {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: left;
				 font-family: Times New Roman;
			}

			.column_biasa_miring {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: left;
				 font-family: Times New Roman;
				 font-style: italic;
			}

			.column_tengah {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: center;
				 font-family: Times New Roman;
				 font-weight: bold;
			}

			.column_tengah_miring {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: center;
				 font-family: Times New Roman;
				 font-weight: bold;
				 font-style: italic;
			}

			.column_miring {
   				 display: table-cell;
   				 font-size: 12px;
   				 text-align: left;
				 font-family: Times New Roman;
				 font-style: italic;
			}

			.noBorder {
				border: none; 
			}

			.judul {
				font-weight: bold;
				font-size: 16px;
				font-family: Times New Roman;
				margin-top: 10px;
				text-align: center;
			}

			.judul_miring {
				font-style: italic;
				font-size: 16px;
				font-family: Times New Roman;
				text-align: center;
			}

			.judul_12 {
				font-weight: bold;
				font-size: 12px;
				margin-top:35px;
				font-family: Times New Roman;
				text-align: center;
			}

			.judul_12_miring {
				font-style: italic;
				font-size: 12px;
				font-family: Times New Roman;
				text-align: center;
			}
			
			.garis{
				font-style: bold;
				text-align: center;
				margin-left: 35px;
				margin-right: 35px;
			}

		</style>
	</head>

<body onLoad='window.print()'>
	<div class="layer-pertama">
		<div class="layer-kedua">

			<div class="judul">
			<p>DAFTAR LULUSAN PELATIHAN</p>
			</div>
			<div class="judul">
			<p>KEGIATAN PENDIDIKAN DAN PELATIHAN KETERAMPILAN BAGI PENCARI KERJA</p>
			</div>
			<div class="judul">
			<p>PROGRAM PKTP DINSOSNAKERTRANS KOTA SURAKARTA</p>
			</div>
			
					<div class="garis">
					</div>
					<br>
				
			
			 <div class="box-body table-responsive no-padding">
               
                  <table border="1" width="100%" >
                    <thead>
                      <tr>
						  <th rowspan="3" >NO</th>
						  <th rowspan="3" >NAMA, ALAMAT DAN NO TELP</th>
						  <th rowspan="3" >NAMA PIMPINAN</th>
						  <th rowspan="3" >NO IJIN</th>
						  <th rowspan="3" >KEJURUAN</th>
						  <th rowspan="3" >KAPASITAS LATIH</th>
						  <th rowspan="1" colspan="2" >JML DILATIH</th>
						  <th rowspan="1" colspan="2">JML LULUSAN</th>
						  <th rowspan="1" colspan="4">JML YANG BEKERJA</th>
						</tr>
						<tr>
						<td rowspan="2">L</td>
						<td rowspan="2">P</td>
						<td rowspan="2">L</td>
						<td rowspan="2">P</td>
						<td colspan="2">PERUSAHAAN</td>
						<td colspan="2">MANDIRI</td>
						</tr>
						<tr>
						<td>L</td>
						<td>P</td>
						<td>L</td>
						<td>P</td>
						</tr>
                    </thead>
					
                    <tbody>
                      	<?php  
                      	if( ! empty($lulusan)){
                      	$no = $this->uri->segment('3') + 1;
                      	foreach ($lulusan as $lihat){
							
                    	echo "<tr>";
                        echo "<td>".$no++."</td>";
                    	echo "<td>".$lihat->identitas_lembaga."</td>";
                    	echo "<td>".$lihat->nama_pimpinan."</td>";
						echo "<td>".ucfirst($lihat->no_ijin)."</td>";
						echo "<td>".ucfirst($lihat->kejuruan)."</td>";
						echo "<td>".ucfirst($lihat->kapasitas)."</td>";
						echo "<td>".ucfirst($lihat->dilatih_l)."</td>";
						echo "<td>".ucfirst($lihat->dilatih_p)."</td>";
						echo "<td>".ucfirst($lihat->lulusan_l)."</td>";
						echo "<td>".ucfirst($lihat->lulusan_p)."</td>";
						echo "<td>".ucfirst($lihat->perusahaan_l)."</td>";
						echo "<td>".ucfirst($lihat->perusahaan_p)."</td>";
						echo "<td>".ucfirst($lihat->mandiri_l)."</td>";
						echo "<td>".ucfirst($lihat->mandiri_p)."</td>";
                        echo "</tr>";
						}
							}
						?>
                    </tbody>
                  </table>
				  
				    <a href="<?php echo base_url(); ?>index.php/admins/lulusan">Lulusan</a>
				<br>
				<?php echo $this->pagination->create_links();?>
                  
                </div><!-- /.box-body -->
				
			</div>
			</div>
			
			 
	</body>
	
</html>