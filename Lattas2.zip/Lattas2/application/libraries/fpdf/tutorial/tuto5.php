<?php
require('../fpdf.php');

class PDF extends FPDF
{
// Load data
function LoadData($file)
{
	// Read file lines
	$lines = file($file);
	$data = array();
	foreach($lines as $line)
		$data[] = explode(';',trim($line));
	return $data;
}

// Simple table
function BasicTable($header, $data)
{
	// Header
	foreach($header as $col)
		$this->Cell(40,7,$col,1);
	$this->Ln();
	// Data
	foreach($data as $row)
	{
		foreach($row as $col)
			$this->Cell(40,6,$col,1);
		$this->Ln();
	}
}

// Better table
function ImprovedTable($header, $data)
{
	// Column widths
	$w = array(40, 35, 40, 45);
	// Header
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],7,$header[$i],1,0,'C');
	$this->Ln();
	// Data
	foreach($data as $row)
	{
		$this->Cell($w[0],6,$row[0],'LR');
		$this->Cell($w[1],6,$row[1],'LR');
		$this->Cell($w[2],6,number_format($row[2]),'LR',0,'R');
		$this->Cell($w[3],6,number_format($row[3]),'LR',0,'R');
		$this->Ln();
	}
	// Closing line
	$this->Cell(array_sum($w),0,'','T');
}

// Colored table
function FancyTable($header, $data)
{
	// Colors, line width and bold font
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	// Header
	$w = array(40, 35, 40, 45);
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],7,$header[$i],1,0,'C',true);
	$this->Ln();
	// Color and font restoration
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	// Data
	$fill = false;
	foreach($data as $row)
	{
		$this->Cell($w[0],6,$row[0],'LR',0,'L',$fill);
		$this->Cell($w[1],6,$row[1],'LR',0,'L',$fill);
		$this->Cell($w[2],6,number_format($row[2]),'LR',0,'R',$fill);
		$this->Cell($w[3],6,number_format($row[3]),'LR',0,'R',$fill);
		$this->Ln();
		$fill = !$fill;
	}
	// Closing line
	$this->Cell(array_sum($w),0,'','T');
}
}

$pdf = new PDF();
// Column headings
$header = array('Country', 'Capital', 'Area (sq km)', 'Pop. (thousands)');
// Data loading
$data = $pdf->LoadData('countries.txt');
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->BasicTable($header,$data);
$pdf->AddPage();
$pdf->ImprovedTable($header,$data);
$pdf->AddPage();
$pdf->FancyTable($header,$data);
$pdf->Output();

$this->fpdf->SetFont('Times','B','14');
        $this->fpdf->Cell(0,6,'PEMERINTAH KABUPATEN CIREBON',0,1,'C');
        $this->fpdf->SetFont('Times','B','14');
        $this->fpdf->Cell(0,6,'KECAMATAN LEMAHABANG',0,1,'C');
        $this->fpdf->SetFont('Times','B','16');
        $this->fpdf->Cell(0,6,'KEPALA DESA BELAWA',0,1,'C');
        $this->fpdf->SetFont('Times','','10');
        $this->fpdf->Cell(0,5,'Jalan Raya Desa Belawa No telp (0231)21345 kode pos 45183',0,1,'C');
        $this->fpdf->Cell(0,4,'Website: http://belawa.desa.id | E-Mail: desabelawa@gmail.com',0,1,'C');
        $this->fpdf->SetLineWidth(1);
        $this->fpdf->Line(10,39,198,39);
        $this->fpdf->SetLineWidth(0);
        $this->fpdf->Line(10,40,198,40);
        $this->fpdf->SetFont('Times','B','14');
        $this->fpdf->Cell(0,30,'SURAT KETERANGAN',0,1,'C');
        $this->fpdf->SetLineWidth(0);
        $this->fpdf->Line(78,56,132,56);
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(0,-16,'No : ..../435.417.101/2016',0,1,'C');
        
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(20);
        $this->fpdf->Cell(0,50,'Yang bertanda tangan di bawah ini Kepala desa Belawa kecamatan Lemahabang Kabupaten ',0,1,'L');
        $this->fpdf->Cell(10);
        $this->fpdf->Cell(0,-38,'Cirebon menerangkan bahwa :',0,1,'L');
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,70,'Nama                       : Sastro',0,1,'L');
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,-55,'Tempat, Tgl. Lahir  : Solo',9,0,1,'L');
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,70,'Agama                     : islam' ,0,1,'L');
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,-55,'Pekerjaan                 : mahasiswa',0,1,'L'); 
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,70,'Jenis Kelamin           : pria',0,1,'L'); 
        $this->fpdf->Cell(25);
        $this->fpdf->Cell(0,-55,'Alamat                     : kra',0,1,'L');
        
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(20);
        $this->fpdf->Cell(0,80,'Orang  tersebut diatas, adalah benar-benar warga Desa Belawa Kecamatan Lemahabang ',0,1,'L');
        $this->fpdf->Cell(10);
        $this->fpdf->Cell(0,-65,'Kabupaten Cirebon dan',0,1,'L');
        $this->fpdf->SetFont('Times','B','12');
        $this->fpdf->Cell(51);
        $this->fpdf->Cell(0,66,'Berkelakuan Baik di masyarakat.',0,1,'L');
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(20);
        $this->fpdf->Cell(0,-36,'Demikian surat keterangan ini kami buat, untuk dapat dipergunakan sebagaimana mestinya.',0,1,'L');
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(138);
        $this->fpdf->Cell(0,70,"Belawa  ".date('d M Y'),0,1,'L');
        $this->fpdf->Cell(138);
        $this->fpdf->Cell(0,-60,'Kepala Desa Belawa',0,1,'L');
        $this->fpdf->SetFont('Times','U','12');
        $this->fpdf->Cell(138);
        $this->fpdf->Cell(0,110,'Dwi Gumelar,M.Si',0,1,'L');
        $this->fpdf->SetFont('Times','','12');
        $this->fpdf->Cell(138);
        $this->fpdf->Cell(0,-98,'NIP : 1234567890',0,1,'L');
?>
